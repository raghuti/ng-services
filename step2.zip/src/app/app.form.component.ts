import { Component } from "@angular/core";

@Component({
    selector : 'app-form',
    template : `
    <h3>
        User Name : {{ user.username }}<br/>
        User eMail : {{ user.usermail }}<br/>
        User Age : {{ user.userage }}<br/>
    </h3>
    <hr>
    <form action="#" method="get">
        <table>
        <tr>
            <td>
                <label for="uname">User Name</label>
            </td>
            <td>
                <input id="uname" type="text" [(ngModel)]="user.username" name="uname">
            </td>
        </tr>
        <tr>
            <td>
                <label for="umail">User eMail</label>
            </td>
            <td>
                <input id="umail" type="text" [(ngModel)]="user.usermail" name="umail">
            </td>
        </tr>
        <tr>
            <td>
                <label for="uage">User Age</label>
            </td>
            <td>
                <input id="uage" type="number" [(ngModel)]="user.userage" name="uage">
            </td>
        </tr>
        <tr>
            <td>
               &nbsp;
            </td>
            <td>
                <button>Submit</button>
            </td>
        </tr>
    </table>
    </form>
    `
})
export class FormComponent{

    user = {
        username : "Batman",
        usermail : "bruce@waynefoundation.com",
        userage : 30
    }

}