import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  <app-form></app-form>
  `
})
export class AppComponent{
  constructor(){

  }
  
}
