let express = require("express");
let cors = require("cors");
let data = require("./data.json");
let app = express();

app.use( cors() );

app.get("/data", function(request, response){
    response.send(data)
})

app.listen(2525);
console.log("server is now live on localhost:2525")