import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header.component';
import { GridComponent } from './grid.component';
import { HeroServices } from './hero.service';
import { HERO_TOKEN } from './appValue.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    GridComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [
    { provide: HERO_TOKEN, useValue : "Hello from Valtech Bangalore" },
    { provide : HeroServices, useClass : HeroServices }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
