import { Component, Input } from '@angular/core';
import { HeroServices } from './hero.service';

@Component({
  selector: 'app-header',
  template: `
  <ul class="nav navbar-nav">
  <li *ngFor='let hero of herodata'>
    <a href="/{{ hero.title | lowercase }}">{{ hero.title }}</a>
  </li>
</ul>
  `
})
export class HeaderComponent {
  herodata = [];
  constructor(private hs:HeroServices){
    this.herodata = hs.getHeroData();
  }
}
