import { Component, Inject } from '@angular/core';
import { HERO_TOKEN } from './appValue.service';

@Component({
  selector: 'app-root',
  template: `
  <h1>{{ title }}</h1>
  <app-header></app-header>
  <hr>
  <app-grid></app-grid>

  <h1>Total Heroes : {{ count }}</h1>
  `
})
export class AppComponent {
  title = "";
  count = 0;
  constructor( @Inject(HERO_TOKEN) private ht:string ){
    this.title = this.ht;
  }
}
